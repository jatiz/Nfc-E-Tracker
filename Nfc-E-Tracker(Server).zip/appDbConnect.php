<?php
 define('HOST','mysql.hostinger.co.uk');
 define('USER','u511057710_nfc');
 define('PASS','Nightyeye27');
 define('DB','u511057710_nfc');
 
 $con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');