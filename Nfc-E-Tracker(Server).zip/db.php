<?php
$connection = mysql_connect('mysql.hostinger.co.uk', 'u511057710_nfc', 'Nightyeye27');
if (!$connection){
 die("Database Connection Failed" . mysql_error());
}
$select_db = mysql_select_db('u511057710_nfc');
if (!$select_db){
 die("Database Selection Failed" . mysql_error());
}
?>